package com.main;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.PriorityQueue;

public class Daat {
	public static Object[] getDaatOr(List<LinkedList<Integer>> post) {
		// TODO Auto-generated method stub
		PriorityQueue<Integer> pq=new PriorityQueue<Integer>();
		int k=0;
		LinkedList<Integer>	daat =new LinkedList<Integer>();
		ArrayList<Integer> minVal=new ArrayList<Integer>();
		for (int i = 0; i < post.size(); i++) {
			pq.add(post.get(i).get(k));
		}
		int[] index=new int[post.size()];
		int min=0;
		int comparision=0;
		while(pq.isEmpty()==false){
			comparision=comparision+1;
			min=pq.peek();
			//System.out.println("pq   "+pq);
			daat.add(pq.peek());
			minVal.add(min);
			pq.removeAll(minVal);
			//System.out.println("After del   "+pq);
			for (int i = 0; i < post.size(); i++) {
				if(post.get(i).contains(min)){
					index[i]=index[i]+1;
					if(index[i]<post.get(i).size()){
						pq.add(post.get(i).get(index[i]));
					}
				}
			}
			if(pq.size()==1){
				for (int i = 0; i < post.size(); i++) {
					if(index[i]<post.get(i).size()){
						while(index[i]<post.get(i).size()){
						daat.add(post.get(i).get(index[i]));
						index[i]=index[i]+1;
					}
						return new Object[]{daat,Integer.valueOf(comparision)};
					}
				}
			}
		}

		//System.out.println("c"+comparision);
		return new Object[]{daat,Integer.valueOf(comparision)};
	}


	public static Object[] getDaatAnd(List<LinkedList<Integer>> post) {
		// TODO Auto-generated method stub
		PriorityQueue<Integer> pq=new PriorityQueue<Integer>();

		int k=0;
		LinkedList<Integer> daat=new LinkedList<Integer>();
		ArrayList<Integer> minVal=new ArrayList<Integer>();
		HashSet<Integer> daatOr=new HashSet<Integer>();
		for (int i = 0; i < post.size(); i++) {
			pq.add(post.get(i).get(k));
		}
		//System.out.println("pq this one "+pq);
		int[] index=new int[post.size()];
		int min=0;
		int z=0;
		int comparision=0;
		while(pq.isEmpty()==false){
			
			comparision=comparision+1;
			z=z+1;
			min=pq.peek();
			//daat.add(pq.peek());
			minVal.add(min);
			if(pq.size()==post.size()){
				pq.removeAll(minVal);
			}
			else{
				break;
			}
			//System.out.println("pq   "+pq);
			if(pq.isEmpty()){
				//System.out.println("i  "+z+"post  "+post.size());
				daat.add(min);
			}
			for (int i = 0; i < post.size(); i++) {
				if(post.get(i).contains(min)){
					index[i]=index[i]+1;
					if(index[i]<post.get(i).size()){
						pq.add(post.get(i).get(index[i]));
					}
					//System.out.println("updated pq  "+pq);
				}
			}
		}

		return new Object[]{daat,Integer.valueOf(comparision)};
	}





}
