package com.main;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.PriorityQueue;
import java.util.TreeMap;

import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.Fields;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexableField;
import org.apache.lucene.index.LeafReader;
import org.apache.lucene.index.LeafReaderContext;
import org.apache.lucene.index.MultiFields;
import org.apache.lucene.index.PostingsEnum;
import org.apache.lucene.index.Term;
import org.apache.lucene.index.Terms;
import org.apache.lucene.index.TermsEnum;
import org.apache.lucene.search.DocIdSet;
import org.apache.lucene.search.DocIdSetIterator;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.util.BytesRef;

public class RetrieveQ {

	public static void main(String[] args) throws IOException, InstantiationException, IllegalAccessException {
		
		Path path=Paths.get("src/main/java/index");
		//Path path=Paths.get(args[0]);
		/*"/Desktop/CS Books/FirstSem/IR/Project2/index");*/
		Directory directory=FSDirectory.open(path);;
		IndexReader reader = DirectoryReader.open(directory);
		HashMap<String,LinkedList<Integer>> invertedIndex=new HashMap<String, LinkedList<Integer>>();
		invertedIndex=getInvetedIndex(reader);
		String terms="";
		File file=new File("/home/shikhar/TermInp.txt");
		//File file=new File(args[2]);
		BufferedReader br=new BufferedReader(
				  new InputStreamReader(
	                      new FileInputStream(file), "UTF-8"));
		File fileOutPut=new File("/home/shikhar/output.txt");
		//File fileOutPut=new File(args[1]);
		FileWriter fw=new FileWriter(fileOutPut);
		BufferedWriter bw=new BufferedWriter(fw);
		LinkedList<Integer> intersectionTaaT=null;
		LinkedList<Integer> unionTaaT=null;
		LinkedList<Integer> union=null;
		LinkedList<Integer> l1= null;
		LinkedList<Integer> l2= null;
		StringBuffer termOutput=new StringBuffer();
		StringBuffer termList=null;
		LinkedList<Integer> TaatOr=null;
		int taatCompare=0;
		int taatOrCompare=0;
		int finalTaatOrCompare=0;
		int taatTempCompare;
		
		while((terms=br.readLine())!=null){
			finalTaatOrCompare=0;
			String[] termInline=terms.split(" ");
				intersectionTaaT=new LinkedList<Integer>();
				unionTaaT=new LinkedList<Integer>();
				l1=null;
				termList=new StringBuffer();
				taatCompare=0;
				taatTempCompare=0;
				taatOrCompare=0;
				finalTaatOrCompare=0;
				List<LinkedList<Integer>> postingsForDaat=new ArrayList<LinkedList<Integer>>();
			LinkedList<Integer> l=null;
			
			
			
			for(String term2:termInline){
				postingsForDaat.add(invertedIndex.get(term2));
			}
			//DAAT OR
			Daat daatObj=new Daat();
			Object[] obj2=daatObj.getDaatOr(postingsForDaat);
			LinkedList<Integer> daat=(LinkedList<Integer>)obj2[0];
			int daatOrComp=(Integer) obj2[1];
			HashSet<Integer> h=new HashSet<Integer>(daat);
			LinkedList<Integer> daatOr=new LinkedList<Integer>();
			daatOr.addAll(h);
			Collections.sort(daatOr);
			//System.out.println("daat OR "+daatOr);
		//	System.out.println("This is DAAT OR  "+daatOr);
			//DAAT AND
			obj2=daatObj.getDaatAnd(postingsForDaat);
			LinkedList<Integer> daatAnd=(LinkedList<Integer>)obj2[0];
			int daatAndComp=(Integer) obj2[1];
			//System.out.println("This is DAAT AND  "+daatAnd);
			
			for(String term:termInline){
				if(l1!=null){
					l2=new LinkedList<Integer>();
					l2=invertedIndex.get(term);
					String toFile=invertedIndex.get(term).toString();
					termOutput.append("GetPostings\n");
					termOutput.append(term+"\n");
					if(toFile!=null)
						termOutput.append("Postings list: "+toFile.substring(1,toFile.length()-1).replace(",","")+"\n");
					//termOutput.append("Postings list: "+invertedIndex.get(term).toString()+"\n");
					termList.append(term+" ");
					int p1=0;
					int p2=0;
					union=new LinkedList<Integer>();
					union=l1;
					//	TAAT IMPLEMENTATION
					//TAAT AND
					Taat taat=new Taat();
					Object[] obj=taat.getTaatAnd(intersectionTaaT, l2);
					intersectionTaaT=(LinkedList<Integer>) obj[0];
					taatTempCompare=(Integer) obj[1];
					taatCompare=taatTempCompare+taatCompare;
					
					//GET TAAT OR
					obj=taat.getTaatOr(unionTaaT, l2);
					unionTaaT=(LinkedList<Integer>) obj[0];
					Collections.sort(unionTaaT);
					HashSet<Integer> hOr=new HashSet<Integer>(unionTaaT);
					TaatOr=new LinkedList<Integer>();
					TaatOr.addAll(hOr);
					taatOrCompare=(Integer) obj[1];
					finalTaatOrCompare=finalTaatOrCompare+taatOrCompare;
					taatTempCompare=0;
				}
				else{
					l1=new LinkedList<Integer>();
					String toFile=invertedIndex.get(term).toString();
					termOutput.append("GetPostings\n");
					termOutput.append(term+"\n");
					if(toFile!=null)
							termOutput.append("Postings list: "+toFile.substring(1,toFile.length()-1).replace(",","")+"\n");
					intersectionTaaT=invertedIndex.get(term);
					unionTaaT=invertedIndex.get(term);
					l1=invertedIndex.get(term);
					termList.append(term+" ");
				}
			}
			
			
			//ADD TAAT AND
			termOutput.append("TaatAnd\n");
			termOutput.append(termList.toString().trim()+"\n");
			if(intersectionTaaT.size()==0){
				termOutput.append("Results: empty\n");
			}
			else{
				termOutput.append("Results: "+intersectionTaaT.toString().substring(1,intersectionTaaT.toString().length()-1).replace(",","")+"\n");
			}
			termOutput.append("Number of documents in results: "+intersectionTaaT.size()+"\n");
			termOutput.append("Number of comparisons: "+taatCompare+"\n");
			
			//ADD TAAT OR
			termOutput.append("TaatOr\n");
			termOutput.append(termList.toString().trim()+"\n");
			Collections.sort(TaatOr);
			if(unionTaaT.size()==0){
				termOutput.append("Results: empty\n");
			}
			else{
				termOutput.append("Results: "+TaatOr.toString().substring(1,TaatOr.toString().length()-1).replace(",","")+"\n");
			}
			termOutput.append("Number of documents in results: "+TaatOr.size()+"\n");
			termOutput.append("Number of comparisons: "+finalTaatOrCompare+"\n");
			//System.out.println("Taat or " +unionTaaT);
			
			//ADD DAAT AND
			termOutput.append("DaatAnd\n");
			termOutput.append(termList.toString().trim()+"\n");
			if(daatAnd.size()==0){
				termOutput.append("Results: empty\n");
			}
			else{
				termOutput.append("Results: "+daatAnd.toString().substring(1,daatAnd.toString().length()-1).replace(",","")+"\n");
			}
			termOutput.append("Number of documents in results: "+daatAnd.size()+"\n");
			termOutput.append("Number of comparisons: "+daatAndComp+"\n");
			//System.out.println("Daat And " +daatAnd);
			
			//ADD DAAT OR
			termOutput.append("DaatOr\n");
			termOutput.append(termList.toString().trim()+"\n");
			if(daatOr.size()==0){
				termOutput.append("Results: empty\n");
			}
			else{
				termOutput.append("Results: "+daatOr.toString().substring(1,daatOr.toString().length()-1).replace(",","")+"\n");
			}
			
			termOutput.append("Number of documents in results: "+daatOr.size()+"\n");
			termOutput.append("Number of comparisons: "+daatOrComp+"\n");
			//System.out.println("Daat or " +daatOr);
		}
		//WRITE TO FILE
		bw.write(termOutput.toString());
		br.close();
		bw.close();
	}
	
	


	public static HashMap<String,LinkedList<Integer>> getInvetedIndex(IndexReader reader) throws IOException{
		Fields fields = MultiFields.getFields(reader);
		Iterator<String> field=fields.iterator();
		HashMap<String,LinkedList<Integer>> hashMap=new HashMap<String, LinkedList<Integer>>();
		LinkedList<Integer> linkedList=null;
		int i=0;
		while(field.hasNext()){
			String fieldsdoc=field.next();

			if(fieldsdoc.equals("text_en")||fieldsdoc.equals("text_es")||fieldsdoc.equals("text_fr")) 
			{  

				Terms terms=fields.terms(fieldsdoc);
				if(terms!=null)
				{
					TermsEnum term=terms.iterator();
					BytesRef text;
					while((text = term.next()) != null)
					{  

						// hash.put(text.utf8ToString(),text.utf8ToString());
						//System.out.println(text.utf8ToString());
						PostingsEnum postingsEnum=MultiFields.getTermDocsEnum(reader, fieldsdoc, text);
						while(postingsEnum.nextDoc()!=DocIdSetIterator.NO_MORE_DOCS){
							//System.out.println(postingsEnum.docID());
							if(hashMap.get(text.utf8ToString()) != null){
								linkedList=new LinkedList<Integer>();
								linkedList=hashMap.get(text.utf8ToString());
								linkedList.add(postingsEnum.docID());
								Collections.sort(linkedList);
								hashMap.put(text.utf8ToString(),linkedList);
							}
							else{
								linkedList=new LinkedList<Integer>();
								linkedList.add(postingsEnum.docID());
								Collections.sort(linkedList);
								hashMap.put(text.utf8ToString(),linkedList);
							}

						}
						//System.out.println(postingsEnum);
						i++;
					}
				}
			}
		}
		return hashMap;
	}
	

}
