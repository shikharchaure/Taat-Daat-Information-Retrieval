package com.main;

import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;

import org.apache.lucene.index.Fields;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.MultiFields;
import org.apache.lucene.index.PostingsEnum;
import org.apache.lucene.index.Terms;
import org.apache.lucene.index.TermsEnum;
import org.apache.lucene.search.DocIdSetIterator;
import org.apache.lucene.util.BytesRef;

public class Taat {
	public static Object[] getTaatAnd(LinkedList<Integer> l1,LinkedList<Integer> l2){
		int p1=0;
		int p2=0;
		int skip1=(int)Math.sqrt(l1.size());
		int skip2=(int)Math.sqrt(l2.size());
		HashMap<Integer , Integer> skipPointersl1=putSkipPointer(l1,skip1);
		HashMap<Integer , Integer> skipPointersl2=putSkipPointer(l2,skip2);
		LinkedList<Integer>	intersection =new LinkedList<Integer>();
		int comparision=0;
		while(p1!=l1.size() && p2!=l2.size()){
		//	System.out.println("p1      p2  \n"+l1.get(p1)+"     "+l2.get(p2));
			if(l1.get(p1).equals(l2.get(p2)))
			{
				//System.out.println("p1**********"+p1+" p2******"+p2);
				//System.out.println("l1 "+l1.get(p1)+ " VS  here l2 "+l2.get(p2));
				comparision=comparision+1;
			//	System.out.println("Comapre+++  "+comparision);
				intersection.add(l2.get(p2));
				p1=p1+1;
				p2=p2+1;

			}
			else{
				if(l1.get(p1)>l2.get(p2)){
					//System.out.println("l1 "+l1.get(p1)+ " VS  here l2 "+l2.get(p2));
					comparision=comparision+1;
				//	System.out.println("Comapre+++  "+comparision);
					if(skipPointersl2.get(l2.get(p2)) != null){
						if (skipPointersl2.get(l2.get(p2))<l1.get(p1)) {
							//System.out.println("l1 "+l1.get(p1)+ " VS  here l2 "+l2.get(p2));
							//comparision=comparision+1;
							//System.out.println("Comapre+++  "+comparision);
							p2=p2+(skip2);
						}
						else{
							//comparision=comparision+1;
							//p1=p1+1;
							p2=p2+1;
						}
					}
					else{
						//comparision=comparision+1; //COMMETN THIS WHY THIS COMP
					p2=p2+1;
					}
				}
				else{
				//	System.out.println("l1 "+l1.get(p1)+ " VS  here l2 "+l2.get(p2));
					comparision=comparision+1;
					if(skipPointersl1.get(l1.get(p1)) != null){
						if (skipPointersl1.get(l1.get(p1))<l2.get(p2)) {
							p1=p1+(skip1);
							//comparision=comparision+1;
						}
						else{
							//comparision=comparision+1;
							p1=p1+1;
						}
					}
					else{
					p1=p1+1;
					//comparision=comparision+1;
					}
				}
			}

		}
		//System.out.println("Totalcomparision***********"+comparision);
		 return new Object[]{intersection,Integer.valueOf(comparision)}; 
		//return intersection;

	}
	
	
	public static Object[] getTaatOr(LinkedList<Integer> l1,LinkedList<Integer> l2){
		int p1=0;
		int p2=0;
		LinkedList<Integer>	union =new LinkedList<Integer>();
		union.addAll(l1);
		int comparisons=0;
		while((p1!=l1.size()) && (p2!=l2.size())){
			if(l1.get(p1).equals(l2.get(p2)))
			{
				comparisons=comparisons+1;
			//	System.out.println("comparisons***********EQUAL*****"+comparisons);
				p1=p1+1;
				p2=p2+1;
			}
			else{
				if(Integer.valueOf(l1.get(p1))>Integer.valueOf(l2.get(p2))){
					//System.out.println("p1  "+l1.get(p1)+" >p2   "+l2.get(p2)+"comaprision "+comparisons);
					union.add(l2.get(p2));
					comparisons=comparisons+1;
					p2=p2+1;
				}
				else if (l1.get(p1)<l2.get(p2)){
					//System.out.println("p1  "+l1.get(p1)+" <p2   "+l2.get(p2)+"comaprision "+comparisons);
					//union.add(l1.get(p2));
					comparisons=comparisons+1;
					p1=p1+1;
				}
			}
		}
		if(p2<l2.size()){
			for (int i = p2; i < l2.size(); i++) {
				union.add(l2.get(i));
			}
		}
		HashSet<Integer > or=new HashSet<Integer>();
		return new Object[]{union,Integer.valueOf(comparisons)};

	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	public static HashMap<Integer,Integer> putSkipPointer(LinkedList<Integer> l, int skip){
		int pointer=0;
		HashMap<Integer , Integer> skipPointers=new HashMap<Integer , Integer>();
		for (int i = 0; i < skip-1; i++) {
			skipPointers.put(l.get(pointer),l.get(pointer+skip));
			pointer=pointer+skip;
			
		}
		return skipPointers;
	}
}
